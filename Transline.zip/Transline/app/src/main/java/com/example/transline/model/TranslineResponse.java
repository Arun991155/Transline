package com.example.transline.model;

import com.google.gson.annotations.SerializedName;

public class TranslineResponse{

	@SerializedName("created_at")
	private long createdAt;

	@SerializedName("location")
	private String location;

	@SerializedName("remark")
	private String remark;

	@SerializedName("id")
	private int id;

	@SerializedName("latlng")
	private String latlng;

	@SerializedName("actDate")
	private String actDate;

	public long getCreatedAt(){
		return createdAt;
	}

	public String getLocation(){
		return location;
	}

	public String getRemark(){
		return remark;
	}

	public int getId(){
		return id;
	}

	public String getLatlng(){
		return latlng;
	}

	public String getActDate(){
		return actDate;
	}
}