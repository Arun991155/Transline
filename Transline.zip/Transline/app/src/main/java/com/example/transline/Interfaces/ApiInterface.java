package com.example.transline.Interfaces;

import com.example.transline.model.TranslineResponse;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface ApiInterface {

    @POST("attendance")
    Call<TranslineResponse> postAttendance(
            @Body HashMap<String ,String > hashMap
    );


}
