package com.example.transline;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.transline.Interfaces.ApiInterface;
import com.example.transline.model.TranslineResponse;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    ImageView imageView;
    FloatingActionButton fltbtn;
    private FusedLocationProviderClient fusedLocationClient;
    private ProgressDialog progressDialog;
    TextView addressTv,latTv,langTV,timeTv;

    private Button btn;
    Double lat = 0.0;
    Double lng =0.0;
    String address = "";
    String time;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageView = findViewById(R.id.imageView);
        fltbtn = findViewById(R.id.floatingActionButton);
        btn = findViewById(R.id.x_button);
        addressTv = findViewById(R.id.address_tv);
        latTv = findViewById(R.id.lat_tv);
        langTV = findViewById(R.id.lang_tv);
        timeTv = findViewById(R.id.time_tv);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Please wait...");
        fltbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION},201);
        }
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(MainActivity.this);
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(MainActivity.this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        if (location != null) {
                            address = getAddressFromLatLng(location.getLatitude(),location.getLongitude());
                            lat = location.getLatitude();
                            lng = location.getLongitude();
                            time = getCurrentTime();
                            addressTv.setText(address);
                            latTv.setText(String.valueOf(lat));
                            langTV.setText(String.valueOf(lng));
                            timeTv.setText(time);


                        }
                    }
                });
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postAttendace(lat+"",lng+"",address,time);
            }
        });


    }

    private String getAddressFromLatLng(double latitude, double longitude) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
            if (addresses != null && !((List<?>) addresses).isEmpty()) {
                Address address = addresses.get(0);
                String fullAddress = address.getAddressLine(0); // Full address with street, city, etc.
                return fullAddress;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "";
    }

    private String getCurrentTime(){
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        Date currentDate = new Date();
        String formattedDate = sdf.format(currentDate);
        return formattedDate;
    }

    public void postAttendace(String lat,String lng,String address , String time){
        progressDialog.show();
        progressDialog.setCanceledOnTouchOutside(false);
        HashMap<String,String> hashMap = new HashMap();
        hashMap.put("latlng",lat+","+lng);
        hashMap.put("location",address);
        hashMap.put("actDate",time);
        hashMap.put("remark","attendance test");
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://x8ki-letl-twmt.n7.xano.io/api:BS3FIkjh/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        ApiInterface api= retrofit.create(ApiInterface.class);
        api.postAttendance(hashMap).enqueue(new Callback<TranslineResponse>() {
            @Override
            public void onResponse(Call<TranslineResponse> call, Response<TranslineResponse> response) {
                if (response.isSuccessful()){
                    Toast.makeText(MainActivity.this, "Attendance marked", Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }
            @Override
            public void onFailure(Call<TranslineResponse> call, Throwable t) {
                Log.e("TAG", "onFailure: " +t.getLocalizedMessage());
            }
        });

    }
}