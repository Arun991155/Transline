package com.example.transline.adapter;

public class OnclickDelegate {
}
